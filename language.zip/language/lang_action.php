<?php

/**
 *      [Discuz!] (C)2001-2099 Comsenz Inc.
 *      This is NOT a freeware, use is subject to license terms
 *
 *      $Id: lang_action.php by Valery Votintsev, codersclub.org
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$lang = array
(
	0	=> 'Register/Login',// '注册/登录',
	1	=> 'Space',// '空间',
	2	=> 'Forum',// '论坛',
	3	=> 'Groups',// '群组',
	4	=> 'Home',// '首页',

	100	=> 'Other',// '其他',
	127	=> 'Plugins',// '插件',

);

