<?php

/**
 *      [Discuz!] (C)2001-2099 Comsenz Inc.
 *      This is NOT a freeware, use is subject to license terms
 *
 *      $Id: lang_blog.php by Valery Votintsev, codersclub.org
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$lang = array
(
	'blog_name'	=> 'Post Blog Task',//'发表日志任务',
	'blog_desc'	=> 'To complete the task, post a blog and get award.',//'发表日志即可完成任务，获得相应的奖励',
	'blog_view'	=> '<strong>Follow the next steps below to complete the task:</strong>
		<ul>
		<li>1. <a href="home.php?mod=spacecp&ac=blog" target="_blank">Click here to open new window to post blog</a>;</li>
		<li>2. Write you first blog and publish it.</li>
		</ul>',
);

