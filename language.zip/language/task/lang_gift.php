<?php

/**
 *      [Discuz!] (C)2001-2099 Comsenz Inc.
 *      This is NOT a freeware, use is subject to license terms
 *
 *      $Id: lang_gift.php by Valery Votintsev, codersclub.org
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$lang = array
(
	'gift_name'	=> 'Gift Task',//'红包类任务',
	'gift_desc'	=> 'Complete this task to get a gift package.',//'申请此任务即可领取红包',
);

