<?php

/**
 *      [Discuz!] (C)2001-2099 Comsenz Inc.
 *      This is NOT a freeware, use is subject to license terms
 *
 *      $Id: lang_email.php by Valery Votintsev, codersclub.org
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$lang = array
(
	'email_name'	=> 'Activate Email Task',//'验证邮箱任务',
	'email_desc'	=> 'Fill your Email, verify it for activation and get award.',//'验证邮箱获得相应的奖励。',
	'email_view'	=> '<strong>Follow the next steps to complete task:</strong>
		<ul>
		<li><a href="home.php?mod=spacecp&ac=profile&op=password" target="_blank">Open in a new window your profile Settings</a>;</li>
		<li>Fill in your real mailbox, and click "Verify Email" button;</li>
		<li>The system will send you an email. Receive this email and click a verification links from this message.</li>
		</ul>',
);

