<?php

/**
 *      [Discuz!] (C)2001-2099 Comsenz Inc.
 *      This is NOT a freeware, use is subject to license terms
 *
 *      $Id: lang_calc.php by Valery Votintsev, codersclub.org
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$lang = array
(
	'calc_name'	=> 'Addition and subtraction inside 100',//'100 以内加减法',
	'calc_desc'	=> 'Show random from 100 verification of addition and subtraction from Questions and Answers',//'随机显示 100 以内加减法的验证问答',
);

