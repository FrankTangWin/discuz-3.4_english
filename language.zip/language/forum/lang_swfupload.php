<?php

/**
 *      [Discuz!] (C)2001-2099 Comsenz Inc.
 *      This is NOT a freeware, use is subject to license terms
 *
 *      $Id: lang_swfupload.php by Valery Votintsev, codersclub.org
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$lang = "
<okbtn>OK</okbtn>
<ctnbtn>Continue</ctnbtn>
<fileName>File name</fileName>
<size>File size</size>
<stat>Upload progress</stat>
<browser>Browse</browser>
<delete>Delete</delete>
<return>Return</return>
<upload>Upload</upload>
<okTitle>Upload completed</okTitle>
<okMsg>File uploaded successfully</okMsg>
<uploadTitle>Uploading</uploadTitle>
<uploadMsg1>Total</uploadMsg1>
<uploadMsg2>Wait for file uploading, progress is</uploadMsg2>
<uploadMsg3>Files</uploadMsg3>
<bigFile>File too large</bigFile>
<uploaderror>Upload failed</uploaderror>
";

