<?php

/**
 *      [Discuz!] (C)2001-2099 Comsenz Inc.
 *      This is NOT a freeware, use is subject to license terms
 *
 *      $Id: lang_thread.php by Valery Votintsev, codersclub.org
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$lang = array (
	'forum_archive' => 'Archive',//'存档',
	'source' => 'Source',//'来源',

	't_question' => '?',
	't_comma' => ',',
	't_exclamatory' => '!',
	't_period' => '.',
	't_suspension' => '...',

);
