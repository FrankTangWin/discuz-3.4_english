<?php

/**
 *      [Discuz!] (C)2001-2099 Comsenz Inc.
 *      This is NOT a freeware, use is subject to license terms
 *
 *      $Id: lang_updateline.php by Valery Votintsev, codersclub.org
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$lang = array
(
	'updateline_name'	=> 'Change Update Time',//'救生圈',
	'updateline_desc'	=> 'Change the post update time to the current time',//'把自己日志的发布时间更新为当前时间',
	'updateline_info'	=> 'Change the post update time to the current time',//'把自己日志的发布时间更新为当前时间',
);

