<?php

/**
 *      [Discuz!] (C)2001-2099 Comsenz Inc.
 *      This is NOT a freeware, use is subject to license terms
 *
 *      $Id: lang_call.php by Valery Votintsev, codersclub.org
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$lang = array
(
	'call_name'	=> 'Call Card',//'点名卡',
	'call_desc'	=> 'Send notification to your friends to come see your blog',//'发通知给自己的好友，让他们来查看自己的日志',
	'call_info'	=> 'Send notification to your friends to come see your blog',//'发通知给自己的好友，让他们来查看自己的日志',
);

