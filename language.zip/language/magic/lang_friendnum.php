<?php

/**
 *      [Discuz!] (C)2001-2099 Comsenz Inc.
 *      This is NOT a freeware, use is subject to license terms
 *
 *      $Id: lang_friendnum.php by Valery Votintsev, codersclub.org
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$lang = array
(
	'friendnum_name'	=> 'Friends expander',//'好友增容卡',
	'friendnum_desc'	=> 'Increase the limit of your Friend list',//'增加好友容量上限',
	'friendnum_info'	=> 'Add {num} friends places',//'额外增加 {num} 个好友上限',
	'friendnum_addnum'	=> 'Increase the number of friends',//'增加好友数',
);

