<?php

/**
 *      [Discuz!] (C)2001-2099 Comsenz Inc.
 *      This is NOT a freeware, use is subject to license terms
 *
 *      $Id: lang_visit.php by Valery Votintsev, codersclub.org
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$lang = array
(
	'visit_name'	=> 'Visit Card',//'互访卡',
	'visit_desc'	=> 'Visit friends / Send greeting to friends / Leave message to friends in a random',//'随机访问好友空间/向好友打招呼/给好友留言',
	'visit_num'	=> 'Friends number to visit',//'访问好友数',
	'visit_info'	=> 'Visit Max {num} friends / Send greetings to friends / Leave message to friends in a random',//'随机访问(最多 {num} 个)好友空间/向好友打招呼/给好友留言',
);

