<?php

/**
 *      [Discuz!] (C)2001-2099 Comsenz Inc.
 *      This is NOT a freeware, use is subject to license terms
 *
 *      $Id: lang_attachsize.php by Valery Votintsev, codersclub.org
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$lang = array
(
	'attachsize_name'	=> 'Attachment Card',//'附件增容卡',
	'attachsize_desc'	=> 'Enlarge your attachment space',//'增加附件容量上限',
	'attachsize_info'	=> 'Increase your attach space on {num} Mb',//'额外增加 {num} M 附件容量上限',
	'attachsize_addsize'	=> 'Add size',//'增加容量',
);

