<?php
/**
 *      [Discuz!] (C)2001-2099 Comsenz Inc.
 *      This is NOT a freeware, use is subject to license terms
 *
 *      $Id: lang_flicker.php by Valery Votintsev, codersclub.org
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
$lang = array
(
	'flicker_name'		=> 'Flicker',//'彩虹炫',
	'flicker_desc'		=> 'Enable to use a rainbow flicker on your post',//'在日志、相册评论中使用彩虹炫',
	'flicker_info'		=> 'Enable to use a rainbow flicker on your post',//'在日志、相册评论中使用彩虹炫',
	'flicker_succeed'	=> 'Flicker used successfully',//'彩虹炫使用成功。',
);