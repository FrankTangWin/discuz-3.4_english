<?php

/**
 *      [Discuz!] (C)2001-2099 Comsenz Inc.
 *      This is NOT a freeware, use is subject to license terms
 *
 *      $Id: lang_thunder.php by Valery Votintsev, codersclub.org
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$lang = array
(
	'thunder_name'	=> 'Thunder',//'雷鸣之声',
	'thunder_desc'	=> 'Generate a global feed record about you are online',//'发布一条全站动态，通知大家自己上线了',
	'thunder_info'	=> 'Generate a global feed record about you are online',//'发布一条全站动态，通知大家自己上线了',
);

