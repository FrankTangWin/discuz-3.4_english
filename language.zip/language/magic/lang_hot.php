<?php

/**
 *      [Discuz!] (C)2001-2099 Comsenz Inc.
 *      This is NOT a freeware, use is subject to license terms
 *
 *      $Id: lang_hot.php by Valery Votintsev, codersclub.org
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$lang = array
(
	'hot_name'	=> 'Add Hot',//'热点灯',
	'hot_desc'	=> 'Add hot value to your own blog',//'把自己的日志热度增加站点推荐的热点值',
	'hot_info'	=> 'Add {num} points to your blog hot value',//'把自己的日志热度增加 {num} 个热点值',
);

