<?php

/**
 *      [Discuz!] (C)2001-2099 Comsenz Inc.
 *      This is NOT a freeware, use is subject to license terms
 *
 *      $Id: lang_downdateline.php by Valery Votintsev, codersclub.org
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$lang = array
(
	'downdateline_name'	=> 'Time Machine',//'时光机',
	'downdateline_desc'	=> 'Enable to modify a publish time of your post to the past time',//'把自己日志的发布时间修改为过去',
	'downdateline_info'	=> 'Enable to modify a publish time of your post to the past time',//'把自己日志的发布时间修改为过去',
);

