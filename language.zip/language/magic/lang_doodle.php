<?php

/**
 *      [Discuz!] (C)2001-2099 Comsenz Inc.
 *      This is NOT a freeware, use is subject to license terms
 *
 *      $Id: lang_doodle.php by Valery Votintsev, codersclub.org
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$lang = array
(
	'doodle_name'	=> 'Graffiti',//'涂鸦板',
	'doodle_desc'	=> 'Enable use of graffiti board in a posting',//'在日志、帖子中使用涂鸦板',
	'doodle_info'	=> 'Enable use of graffiti board in a posting',//'在日志、帖子中使用涂鸦板',
);

