<?php


define('UC_CONNECT', 'mysql');

define('UC_DBHOST', '127.0.0.1');
define('UC_DBUSER', 'bbs_velowave');
define('UC_DBPW', 'YyyM6mByjjjf5bYd');
define('UC_DBNAME', 'bbs_velowave');
define('UC_DBCHARSET', 'utf8');
define('UC_DBTABLEPRE', '`bbs_velowave`.pre_ucenter_');
define('UC_DBCONNECT', 0);

define('UC_CHARSET', 'utf-8');
define('UC_KEY', 'g9Pakef98bY2RcnaGdC1FaP7wcB2a5V6P78d64FcKcS0beQdHd7eAeF778cbd2I1');
define('UC_API', 'https://bbs.velowavebikes.com/uc_server');
define('UC_APPID', '1');
define('UC_IP', '');
define('UC_PPP', 20);
?>